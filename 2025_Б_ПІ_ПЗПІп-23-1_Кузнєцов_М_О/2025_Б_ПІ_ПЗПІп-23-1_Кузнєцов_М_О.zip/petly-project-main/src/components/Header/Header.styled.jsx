import styled from "styled-components";

export const Container = styled.div`
  display: flex;
  padding: 16px 25px 16px 20px;
`;
