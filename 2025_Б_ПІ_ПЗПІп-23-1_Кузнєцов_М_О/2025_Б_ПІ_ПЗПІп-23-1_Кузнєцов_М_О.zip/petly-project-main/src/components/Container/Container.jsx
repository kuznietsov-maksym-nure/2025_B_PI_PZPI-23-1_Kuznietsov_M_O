import { MainContainer } from "./Container.styled";

// Загальний контейнер
export const Container = ({ children }) => {
  return <MainContainer>{children}</MainContainer>;
};
