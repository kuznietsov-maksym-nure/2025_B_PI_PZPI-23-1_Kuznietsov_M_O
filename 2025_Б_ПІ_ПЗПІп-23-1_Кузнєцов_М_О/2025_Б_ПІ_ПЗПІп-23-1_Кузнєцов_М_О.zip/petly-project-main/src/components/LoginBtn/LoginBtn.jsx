import { Button } from "./LoginBtn.styled";

export const LoginBtn = ({ text }) => {
  return <Button type="submit">{text}</Button>;
};
