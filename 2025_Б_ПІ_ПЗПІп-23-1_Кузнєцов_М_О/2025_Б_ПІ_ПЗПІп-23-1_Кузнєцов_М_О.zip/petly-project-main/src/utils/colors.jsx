export const colors = {
  primaryText: "#111111",
  inputPriText: "#11111199",
  inputSecText: "rgba(27, 27, 27, 0.6)",
  white: "#FFFFFF",
  black: "#000000",
  accentOrange: "#F59256",
  blurOrange: "rgba(245, 146, 86, 1)",
  hzModalPet: "#fdf7f2",
  darkOrange: "#FF6101",
  markList: "#ffffff99",
  blue: "#3091eb",
  newsText: "#111321",
};
