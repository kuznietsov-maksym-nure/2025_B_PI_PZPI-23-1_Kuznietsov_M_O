export const selectIsLoading = (state) => state.pets.isLoading;
export const selectError = (state) => state.pets.error;
export const selectPets = (state) => state.pets.items;
