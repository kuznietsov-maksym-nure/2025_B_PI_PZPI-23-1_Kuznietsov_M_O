export const selectIsNoticesLoading = (state) => state.notice.isLoading;
export const selectError = (state) => state.notice.error;
export const selectNotices = (state) => state.notice.items;
export const selectPagesInfo = (state) => state.notice.pagesInfo;
